#'PlanTrailCostSlope
#'
#'With this function you can plan a hiking route for a predefined area
#'
#'@param
#'
#'@return
#'
#'@examples
#'
#'@export
#'

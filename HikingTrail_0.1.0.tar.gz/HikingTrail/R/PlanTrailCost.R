#'PlanTrail_cost
#'
#'With this function you can plan a hiking route for a predefined area
#'only cost
#'
#'@param
#'
#'@return
#'
#'@examples
#'
#'@export
#'
#'
#'

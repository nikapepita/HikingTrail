#'HikingTrail
#'
#'Hiking Trail - Rough Planning
#'
#'@docType package
#'
#'@author Annika Ludwig \ email{annika.ludwig@posteo.de}
#'
#'
#'@name HikingTrail
#'

